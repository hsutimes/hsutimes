CREATE PROCEDURE getCourseByTeacherUsername(IN username VARCHAR(32))
  SELECT course
  FROM class
  WHERE teacher = (
    SELECT t_name
    FROM teacher
    WHERE t_username = username
  );
