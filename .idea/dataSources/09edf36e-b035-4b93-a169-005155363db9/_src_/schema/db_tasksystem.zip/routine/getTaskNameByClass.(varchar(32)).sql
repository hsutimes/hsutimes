CREATE PROCEDURE getTaskNameByClass(IN course VARCHAR(32))
  SELECT t_taskname
  FROM task_info
  WHERE keyClass = getKeyClassByCourse(course);
