CREATE PROCEDURE getAdmin()
  SELECT *
  FROM admin;
