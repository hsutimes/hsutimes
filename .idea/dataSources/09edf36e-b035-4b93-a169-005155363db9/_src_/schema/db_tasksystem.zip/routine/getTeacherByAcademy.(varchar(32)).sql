CREATE PROCEDURE getTeacherByAcademy(IN c_academy VARCHAR(32))
  SELECT DISTINCT teacher
  FROM class
  WHERE academy = c_academy;
