CREATE PROCEDURE getTeacherByUsername(IN username VARCHAR(32))
  SELECT t_name
  FROM teacher
  WHERE t_username = username;
