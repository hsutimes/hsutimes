CREATE PROCEDURE addLog(IN l_username VARCHAR(32), IN l_role VARCHAR(32))
  INSERT INTO access_log
  VALUES (NULL, l_username, now(), l_role);
