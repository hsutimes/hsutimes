CREATE PROCEDURE addTaskInfo(IN course VARCHAR(32), IN taskname VARCHAR(32), IN info VARCHAR(255))
  IF isExistTaskName(taskname) = 'false' THEN
    INSERT INTO task_info VALUES (getKeyClassByCourse(course), taskname, info);
  END IF;
