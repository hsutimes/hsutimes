CREATE FUNCTION isExistTeacher(username VARCHAR(32))
  RETURNS VARCHAR(10)
  BEGIN
    DECLARE result VARCHAR(10);
    IF EXISTS(SELECT *
              FROM teacher
              WHERE t_username = username)
    THEN
      SET result = 'true';
    ELSE
      SET result = 'false';
    END IF;
    RETURN (result);
  END;
