CREATE FUNCTION validateUser(uid CHAR(16), token CHAR(255))
  RETURNS CHAR(10)
  BEGIN
DECLARE result char(10);
DECLARE tok char(255);

SELECT `value` FROM t_validate WHERE `key` = uid INTO tok;

IF tok = token THEN
SET result = "true";
ELSE
SET result = "false";
END IF;
 
RETURN result;
END;
