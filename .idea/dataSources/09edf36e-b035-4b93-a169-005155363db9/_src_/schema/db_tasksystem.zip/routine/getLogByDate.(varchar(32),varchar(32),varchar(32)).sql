CREATE PROCEDURE getLogByDate(IN l_year VARCHAR(32), IN l_month VARCHAR(32), IN l_day VARCHAR(32))
  SELECT *
  FROM access_log
  WHERE YEAR(date) = l_year
        AND month(date) = l_month
        AND day(date) = l_day;
