CREATE PROCEDURE getAcademy()
  SELECT DISTINCT academy
  FROM class;
