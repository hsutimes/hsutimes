CREATE PROCEDURE addClass(IN c_course VARCHAR(32), IN c_teacher VARCHAR(32), IN c_academy VARCHAR(32))
  INSERT INTO class
  VALUES (NULL, c_course, c_teacher, c_academy);
