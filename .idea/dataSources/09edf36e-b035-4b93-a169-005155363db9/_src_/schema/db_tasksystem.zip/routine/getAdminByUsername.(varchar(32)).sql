CREATE PROCEDURE getAdminByUsername(IN username VARCHAR(32))
  SELECT a_name
  FROM admin
  WHERE a_username = username;
