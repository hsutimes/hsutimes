CREATE PROCEDURE updateStudentByUsername(IN username VARCHAR(32), IN name VARCHAR(32))
  UPDATE student
  SET s_name = name
  WHERE s_username = username;
