CREATE PROCEDURE addAdmin(IN username VARCHAR(32))
  IF isExistAdmin(username) = 'false' THEN
    INSERT INTO admin VALUES (NULL, username, NULL);
  END IF;
