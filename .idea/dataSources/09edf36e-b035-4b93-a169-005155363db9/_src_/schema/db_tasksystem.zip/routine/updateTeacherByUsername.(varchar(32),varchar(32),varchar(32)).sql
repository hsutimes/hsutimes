CREATE PROCEDURE updateTeacherByUsername(IN username VARCHAR(32), IN name VARCHAR(32), IN academy VARCHAR(32))
  UPDATE teacher
  SET t_name = name, t_academy = academy
  WHERE t_username = username;
