CREATE PROCEDURE getStudentByUsername(IN username VARCHAR(32))
  SELECT s_name
  FROM student
  WHERE s_username = username;
