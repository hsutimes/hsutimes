CREATE FUNCTION getKeyStudentByUsername(username VARCHAR(32))
  RETURNS INT
  RETURN (
    SELECT keyStudent
    FROM student
    WHERE s_username = username
  );
