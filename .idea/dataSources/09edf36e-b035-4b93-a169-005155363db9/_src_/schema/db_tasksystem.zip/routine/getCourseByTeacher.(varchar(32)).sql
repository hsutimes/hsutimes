CREATE PROCEDURE getCourseByTeacher(IN c_teacher VARCHAR(32))
  SELECT DISTINCT course
  FROM class
  WHERE teacher = c_teacher;
