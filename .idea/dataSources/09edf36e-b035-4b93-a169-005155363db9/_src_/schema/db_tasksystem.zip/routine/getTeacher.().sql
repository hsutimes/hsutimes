CREATE PROCEDURE getTeacher()
  SELECT *
  FROM teacher;
