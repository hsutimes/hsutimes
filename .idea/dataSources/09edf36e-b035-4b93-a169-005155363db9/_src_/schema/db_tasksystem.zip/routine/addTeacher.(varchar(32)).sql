CREATE PROCEDURE addTeacher(IN username VARCHAR(32))
  IF isExistTeacher(username) = 'false' THEN
    INSERT INTO teacher (t_username) VALUES (username);
  END IF;
