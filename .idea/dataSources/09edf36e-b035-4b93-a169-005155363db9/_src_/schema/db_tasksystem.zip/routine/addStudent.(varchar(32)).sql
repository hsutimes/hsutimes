CREATE PROCEDURE addStudent(IN username VARCHAR(32))
  IF isExistStudent(username) = 'false' THEN
    INSERT INTO student VALUES (NULL, username, NULL);
  END IF;
