CREATE PROCEDURE getStudent()
  SELECT *
  FROM student;
