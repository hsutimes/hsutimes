CREATE PROCEDURE getTaskInfoByTaskName(IN taskname VARCHAR(32))
  SELECT taskinfo
  FROM task_info
  WHERE t_taskname = taskname;
