CREATE PROCEDURE getClassInfoByCourse(IN c_course VARCHAR(32))
  SELECT
    s_username,
    s_name
  FROM student
  WHERE keyStudent IN (
    SELECT r_student
    FROM record
    WHERE r_class = getKeyClassByCourse(c_course)
  );
