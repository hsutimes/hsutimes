CREATE PROCEDURE addRecordByUsernameAndCourse(IN username VARCHAR(32), IN course VARCHAR(32))
  INSERT INTO record
  VALUES (NULL, getKeyStudentByUsername(username), getKeyClassByCourse(course));
