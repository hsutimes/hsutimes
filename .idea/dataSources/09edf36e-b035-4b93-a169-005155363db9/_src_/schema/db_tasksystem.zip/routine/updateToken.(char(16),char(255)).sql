CREATE PROCEDURE updateToken(IN uid CHAR(16), IN token CHAR(255))
  BEGIN

DECLARE flag CHAR(10);
SELECT `key` FROM t_validate WHERE `key` = uid INTO flag;

IF flag IS NULL THEN
	INSERT INTO t_validate VALUES(uid,token);
ELSE
	UPDATE t_validate SET `value` = token WHERE `key` = uid; 
END IF;

END;
