CREATE PROCEDURE getCourseByStudentUsername(IN username VARCHAR(32))
  SELECT course, teacher, academy
  FROM class
  WHERE keyClass IN (
    SELECT r_class
    FROM record
    WHERE r_student = getKeyStudentByUsername(username)
  );
