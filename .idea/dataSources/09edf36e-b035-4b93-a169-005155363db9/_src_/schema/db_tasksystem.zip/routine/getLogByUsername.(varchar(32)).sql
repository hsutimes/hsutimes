CREATE PROCEDURE getLogByUsername(IN a_username VARCHAR(32))
  SELECT *
  FROM access_log
  WHERE username = a_username;
