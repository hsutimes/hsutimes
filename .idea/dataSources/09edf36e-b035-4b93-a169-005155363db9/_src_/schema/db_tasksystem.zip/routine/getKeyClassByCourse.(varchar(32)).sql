CREATE FUNCTION getKeyClassByCourse(c_course VARCHAR(32))
  RETURNS INT
  RETURN (
    SELECT keyClass
    FROM class
    WHERE course = c_course
  );
