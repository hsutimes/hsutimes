CREATE PROCEDURE deleteUserById(IN id INT(10))
  DELETE FROM blog_user
  WHERE u_id = id;
