CREATE PROCEDURE getUserByName(IN name VARCHAR(10))
  SELECT *
  FROM blog_user
  WHERE u_name = name;
