CREATE PROCEDURE getComment()
  SELECT *
  FROM blogcomment;
