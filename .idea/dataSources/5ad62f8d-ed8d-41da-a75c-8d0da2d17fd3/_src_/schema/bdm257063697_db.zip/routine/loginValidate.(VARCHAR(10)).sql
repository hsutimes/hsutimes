CREATE PROCEDURE loginValidate(IN name VARCHAR(10))
  SELECT u_password
  FROM blog_user
  WHERE u_name = name;
