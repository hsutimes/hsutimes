CREATE FUNCTION getUserNum()
  RETURNS INT
  BEGIN
    DECLARE num INT;
    SET num = (SELECT COUNT(*)
               FROM blog_user);
    RETURN num;
  END;
