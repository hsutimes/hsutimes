CREATE PROCEDURE getCommentBySex(IN c_sex VARCHAR(2))
  SELECT *
  FROM blogcomment
  WHERE sex = c_sex;
