CREATE PROCEDURE updateUserById(IN id INT(10), IN name VARCHAR(10), IN sex VARCHAR(2), IN email VARCHAR(20))
  UPDATE blog_user
  SET u_name = name, u_sex = sex, u_email = email
  WHERE u_id = id;
