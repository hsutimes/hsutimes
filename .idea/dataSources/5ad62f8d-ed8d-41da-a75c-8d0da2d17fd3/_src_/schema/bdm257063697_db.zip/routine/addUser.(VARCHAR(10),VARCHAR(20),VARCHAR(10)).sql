CREATE PROCEDURE addUser(IN name VARCHAR(10), IN password VARCHAR(20), IN role VARCHAR(10))
  IF isExistUser(name) = 'false'
  THEN
    INSERT INTO blog_user (u_name, u_password, u_role, u_date)
    VALUES (name, password, role, NOW());
  END IF;
