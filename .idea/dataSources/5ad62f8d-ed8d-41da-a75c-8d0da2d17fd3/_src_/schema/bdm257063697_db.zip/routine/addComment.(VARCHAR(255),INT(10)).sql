CREATE PROCEDURE addComment(IN info VARCHAR(255), IN user_id INT(10))
  INSERT blog_comment (c_info, c_user_id, c_date)
  VALUES (info, user_id, NOW());
