CREATE FUNCTION isExistUser(name VARCHAR(10))
  RETURNS VARCHAR(5)
  CHARSET gbk
  BEGIN
    DECLARE result VARCHAR(5);
    IF EXISTS(SELECT *
              FROM blog_user
              WHERE u_name = name)
    THEN
      SET result = 'true';
    ELSE
      SET result = 'false';
    END IF;
    RETURN (result);
  END;
