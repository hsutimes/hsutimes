CREATE PROCEDURE deleteUserById(IN id INT)
  DELETE FROM blog_user
  WHERE u_id = id;
