CREATE PROCEDURE getCommentsLimitNum(IN l INT)
  SELECT *
  FROM blogcomment
  LIMIT l;
