CREATE PROCEDURE updateUserPasswordByName(IN name VARCHAR(10), IN password VARCHAR(20))
  UPDATE blog_user
  SET u_password = password
  WHERE u_name = name;
