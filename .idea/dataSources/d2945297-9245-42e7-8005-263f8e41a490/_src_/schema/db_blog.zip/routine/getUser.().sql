CREATE PROCEDURE getUser()
  SELECT *
  FROM blog_user;
