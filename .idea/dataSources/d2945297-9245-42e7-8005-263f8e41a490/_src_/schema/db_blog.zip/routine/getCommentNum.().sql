CREATE FUNCTION getCommentNum()
  RETURNS INT
  BEGIN
    DECLARE num INT;
    SET num = (SELECT COUNT(*)
               FROM blog_comment);
    RETURN num;
  END;
