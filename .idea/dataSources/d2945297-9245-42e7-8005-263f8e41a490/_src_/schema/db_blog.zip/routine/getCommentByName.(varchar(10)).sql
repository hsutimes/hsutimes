CREATE PROCEDURE getCommentByName(IN c_name VARCHAR(10))
  SELECT *
  FROM blogcomment
  WHERE name = c_name;
