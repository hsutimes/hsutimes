CREATE PROCEDURE getCommentByDate(IN year VARCHAR(5), IN month VARCHAR(5), IN day VARCHAR(5))
  SELECT *
  FROM blogcomment
  WHERE YEAR(date) = year AND MONTH(date) = month AND DAY(date) = day;
