CREATE VIEW blogcomment AS
  SELECT
    `comment`.`c_id`   AS `id`,
    `comment`.`c_info` AS `info`,
    `user`.`u_name`    AS `name`,
    `user`.`u_sex`     AS `sex`,
    `user`.`u_role`    AS `role`,
    `user`.`u_email`   AS `email`,
    `comment`.`c_date` AS `date`
  FROM `db_blog`.`blog_comment` `comment`
    JOIN `db_blog`.`blog_user` `user`
  WHERE (`comment`.`c_user_id` = `user`.`u_id`);
